CREATE VIEW ProductsView AS
SELECT * FROM products; 