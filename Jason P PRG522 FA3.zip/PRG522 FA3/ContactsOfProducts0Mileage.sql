SELECT DISTINCT s.phone_number, s.supplier_name
FROM supplier s
JOIN supplier_products sp on s.supplier_id = sp.supplier_id
JOIN products p ON sp.stock_number = p.stock_number
WHERE p.mileage = 0;