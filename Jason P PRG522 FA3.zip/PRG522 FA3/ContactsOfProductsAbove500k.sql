SELECT DISTINCT s.contact
FROM Supplier s
JOIN Supplier_Products sp ON s.supplier_id = sp.supplier_id
JOIN Products p ON sp.stock_number = p.stock_number
WHERE p.price > 500000;
