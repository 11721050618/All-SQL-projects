SELECT DISTINCT make, model, year, transmission
FROM products
WHERE year = 2022 AND transmission = 'Automatic';