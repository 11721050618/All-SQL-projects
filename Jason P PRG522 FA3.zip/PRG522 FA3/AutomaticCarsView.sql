CREATE VIEW AutomaticCars AS
SELECT * FROM products 
WHERE products.transmission = 'Automatic';