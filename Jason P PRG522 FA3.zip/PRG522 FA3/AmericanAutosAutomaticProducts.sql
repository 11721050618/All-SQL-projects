SELECT p.*, s.supplier_name
FROM products p
JOIN supplier_products sp ON p.stock_number = sp.stock_number
JOIN supplier s ON sp.supplier_id = s.supplier_id
WHERE s.supplier_name = 'American Autos' AND p.transmission = 'Automatic';