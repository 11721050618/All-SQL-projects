SELECT make AS MakeAndCountry
FROM products
UNION
SELECT country AS MakeAndCountry
FROM supplier;