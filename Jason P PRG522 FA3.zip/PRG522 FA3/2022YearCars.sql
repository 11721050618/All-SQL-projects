CREATE VIEW YearCars AS
SELECT p.*
FROM products p
WHERE p.year = 2022;