SELECT p.*, s.supplier_name, s.country
FROM Products p
JOIN Supplier_Products sp ON p.stock_number = sp.stock_number
JOIN Supplier s ON sp.supplier_id = s.supplier_id
WHERE s.country = 'USA';



